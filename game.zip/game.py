class Game:
    def __init__(self, name, health, damage, chance_krit_damage, enemy):
        self.name = name
        self.health = health
        self.damage = damage
        self.chance_krit_damage = chance_krit_damage
        self.enemy = enemy

    def next_lvl(self):
        pass

    def dungeon(self):
        pass

    def quest(self):
        pass


def menu(stats):

    print("                                 МЕНЮ                                 ")
    print("----------------------------------------------------------------------")
    print(f"     Статы персонажа {stats['name']}:\nЗдоровье: {stats['health']}\nУрон: {stats['damage']}\n"
          f"chance_krit_damage: {stats['chance_krit_damage']}")
    print(f"     Вы можете выбрать следующие действия:\n1) Спуститься в подземелье (повышает статы)\n"
          f"2) Перейти к новому уровню\n3) Выполнить квест\n4) Закончить игру")
    print("----------------------------------------------------------------------")
    act = input("Что ты выберешь(1/2/3/4)? ")
    if act not in '1234':
        while act not in '1234':
            print("Выбрать можно только 1, 2, 3 или 4!")
            act = input("давай еще раз: ")
    match act:
        case "4":
            print("Ты вышел из игры. До новых встреч!")


def start():
    enemy = ["Обезьянка в ширме", "Обезьянка-страж", "Госпожа бабочка", "Гёбу Масатака Онива", "Гэнитиро Асина",
             "Великий Змей", "Великий Синоби Филин", "Токудзиро обжора", "Эмма", "Иссин"]
    print("Здравствуй, дорогой игрок")
    entry = input("Хочешь ли ты войти в игру (да/нет)? ").lower()
    if entry not in ['да', 'нет']:
        while entry not in ['да', 'нет']:
            print("Ввести можно только 'да' или нет'!")
            entry = input("попробуйте еще раз: ")
    if entry == 'нет':
        print("Как пожелаешь.")
    else:
        print(f'И так, давай начнем. Всего в игре 10 уровней, которые тебе предстоит пройти ни разу не умерев. \n'
              'У твоего персонажа будут основные атрибуты: урон, уровень здоровья, шанс критического урона и \n'
              'уровень брони. Также у тебя будет возможность прокачать атрибуты за счет выполнения каких-то заданий \n'
              'или тренировок. Пока что это все.')
        name = input("Введи имя своего персонажа: ")
        stats = {'name': name, 'damage': 15, 'health': 250, 'chance_krit_damage': 3}
        menu(stats)


start()
